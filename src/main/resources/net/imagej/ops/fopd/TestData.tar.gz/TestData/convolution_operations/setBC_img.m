function [ paddedU ] = setBC_img( paddedU, offsets, sizeU, boundarycondition )
%PAD_IMG pads a img with zeros or replicating boundaries
%   Detailed explanation goes here
numDims = ndims(paddedU);


if numDims == 3 
    if strcmp(boundarycondition, 'replicate')
        for i = 1:offsets(1)
            paddedU(i, :, :) = paddedU(offsets(1) + 1, :, :) ;
            paddedU(i + sizeU(1) + offsets(1), :, :) = paddedU(offsets(1) + sizeU(1), :, :) ;
        end
        for i = 1:offsets(2)
            paddedU(:, i, :) = paddedU(:, offsets(2) + 1, :) ;
            paddedU(:, i + sizeU(2) + offsets(2), :) = paddedU(:, offsets(2) + sizeU(2), :) ;
        end
        for i = 1:offsets(3)
            paddedU(:, :, i) = paddedU(:, :, offsets(3) + 1) ;
            paddedU(:, :, i + sizeU(3) + offsets(3)) = paddedU(:, :, offsets(3) + sizeU(3)) ;
        end
    elseif strcmp(boundarycondition, 'zero')
        z = zeros(sizeU(2) + offsets(2) * 2, sizeU(3) + offsets(3) * 2);
        for i = 1:offsets(1)
            paddedU(i, :, :) = z ;
            paddedU(i + sizeU(1) + offsets(1), :, :) = z ;
        end
        z = zeros(sizeU(1) + offsets(1) * 2, sizeU(3) + offsets(3) * 2);
        for i = 1:offsets(2)
            paddedU(:, i, :) = z ;
            paddedU(:, i + sizeU(2) + offsets(2), :) = z ;
        end
        z = zeros(sizeU(1) + offsets(1) * 2, sizeU(2) + offsets(2) * 2);
        for i = 1:offsets(3)
            paddedU(:, :, i) = z ;
            paddedU(:, :, i + sizeU(3) + offsets(3)) = z ;
        end
    else
        error('Unknown boundarycondition')
    end
elseif numDims == 2
    if strcmp(boundarycondition, 'replicate')
        for i = 1:offsets(1)
            paddedU(i, :) = paddedU(offsets(1) + 1, :) ;
            paddedU(i + sizeU(1) + offsets(1), :) = paddedU(offsets(1) + sizeU(1), :) ;
        end
        for i = 1:offsets(2)
            paddedU(:, i) = paddedU(:, offsets(2) + 1) ;
            paddedU(:, i + sizeU(2) + offsets(2)) = paddedU(:, offsets(2) + sizeU(2)) ;
        end

    elseif strcmp(boundarycondition, 'zero')
        z = zeros(1, sizeU(2) + offsets(2) * 2);
        for i = 1:offsets(1)
            paddedU(i, :) = z ;
            paddedU(i + sizeU(1) + offsets(1), :) = z ;
        end
        z = zeros(sizeU(1) + offsets(1) * 2, 1);
        for i = 1:offsets(2)
            paddedU(:, i) = z ;
            paddedU(:, i + sizeU(2) + offsets(2)) = z ;
        end
    else
        error('Unknown boundarycondition')
    end
end
end

