function [ fftpad, pad ] = pad_kernel( h, dims )
%PAD_KERNEL pads a kernel with zeros
%   Detailed explanation goes here
numDims = ndims(h);
sizeH = size(h);
if sum(sizeH == 1)
    numDims = 1;
end
pad = zeros( dims);

center = ceil( dims./2 );

if numDims == 1
    pad(center(1)-floor(sizeH(1)/2)+1:center(1)+floor(sizeH(1)/2)+1) = h;
elseif numDims == 2
    pad(center(1)-floor(sizeH(1)/2)+1:center(1)+floor(sizeH(1)/2)+1, ...
        center(2)-floor(sizeH(2)/2)+1:center(2)+floor(sizeH(2)/2)+1) = h;
elseif numDims == 3
    pad(center(1)-floor(sizeH(1)/2)+1:center(1)+floor(sizeH(1)/2)+1, ...
        center(2)-floor(sizeH(2)/2)+1:center(2)+floor(sizeH(2)/2)+1, ...
        center(3)-floor(sizeH(3)/2)+1:center(3)+floor(sizeH(3)/2)+1) = h;
end
fftpad = fftn(pad);
end

