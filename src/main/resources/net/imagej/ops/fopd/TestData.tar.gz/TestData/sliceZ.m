function [ img ] = sliceZ( img, s )
%SAMPLEZ Summary of this function goes here
%   Detailed explanation goes here
e = size(img,3);
e = floor(e/s)*s;
img = img(:,:,1:s:e);
end

