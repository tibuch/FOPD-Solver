function [ sizeU, offsets, dims ] = init( u, kernelSize )
%INIT return the size of the input image u, the needed offsets for this
%kernel and the dimensions of the extended image u.
%   Detailed explanation goes here
    sizeU = size(u);
    dims = 2 * floor(kernelSize ./ 2) + size(u);
    offsets = floor(kernelSize ./ 2);
end

