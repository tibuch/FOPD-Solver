function [ view0, psf0, view90, psf90 ] = createDataWithPoissonNoise( groundtruth, psf0, psf90, snr, sliceFactor )

img = single(im2double(groundtruth));

view0 = img;

view0 = gather(single_fft_conv_cpu(view0, psf0, 'replicate'));
view0 = sliceZ(view0, sliceFactor);
view0 = applyPoissonNoise(view0, snr);
view0(isnan(view0)) = 0;
view0 = view0 - min(view0(:));
view0 = view0 ./ max(view0(:));

[y, x, z] = ndgrid(linspace(1, size(view0,1), size(view0,1)), ...
                 linspace(1, size(view0,2), size(view0,2)), ...
                 linspace(1, size(view0,3), 150));
            
view0 = interp3(view0, x, y, z);

view90 = permute(img, [3 2 1]);

psf90 = psf90./sum(psf90(:));

view90 = gather(single_fft_conv_cpu(view90, psf90, 'replicate'));
view90 = sliceZ(view90, sliceFactor);
view90 = applyPoissonNoise(view90, snr);
view90(isnan(view90)) = 0;
view90 = view90 - min(view90(:));
view90 = view90 ./ max(view90(:));

[y, x, z] = ndgrid(linspace(1, size(view90,1), size(view90,1)), ...
                 linspace(1, size(view90,2), size(view90,2)), ...
                 linspace(1, size(view90,3), 150));
            
view90 = interp3(view90, x, y, z);

view0 = single(view0);
psf0 = single(psf0);
view90 = single(permute(view90, [3 2 1]));
psf90 = single(permute(psf90, [3 2 1]));

end

