function [ sizeU, offsets, dims ] = init_padded( paddedU, h )
%INIT_PADDED is used if the input image is already padded.
%   Detailed explanation goes here
    dims = size(paddedU);
    offsets = floor(size(h) ./ 2);
    sizeU = dims - 2 * floor(size(h) ./ 2);
end

