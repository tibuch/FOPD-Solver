function [ out ] = single_fft_conv_cpu( u, h, boundarycondition )
%SINGLE_FFT_CONV_CPU Summary of this function goes here
%   Detailed explanation goes here

%FFT_CONV fft based convolutuion with image u and kernel h
%   kernel h is assumed to be smaller than image u


[ ~, offsets, dims ] = init(u, size(h));

u = embed(u, offsets, boundarycondition);
[h, ~] = pad_kernel(h, dims);

out = fft_conv(u, h);

out = finish(out, offsets);
end

