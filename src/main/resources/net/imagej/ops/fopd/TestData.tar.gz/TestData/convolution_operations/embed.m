function [ u ] = embed( u, offsets, boundarycondition )
%FFT_EMBED Summary of this function goes here
%   Detailed explanation goes here
if strcmp(boundarycondition, 'replicate')
    u = padarray( u, offsets, 'replicate');
elseif strcmp(boundarycondition, 'zero')
    u = padarray( u, offsets, 0);
else
    error('Unknown boundarycondition')
end
end

