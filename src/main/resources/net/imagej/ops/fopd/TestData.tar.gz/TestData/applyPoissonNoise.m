function [ img ] = applyPoissonNoise( img, N )
%APPLYPOISSONNOISE Summary of this function goes here
%   Detailed explanation goes here

img = im2double(img)*N;
img = poissrnd(img);
img = img ./ max(img(:));

end


