function [ out ] = fft_conv( u, h )
%FFT_CONV fft based convolutuion with image u and kernel h
%   kernel h is assumed to be smaller than image u

out = real( fftshift( ifftn( fftn(u) .* h ) ) ) ;
end

