function [ result ] = finish( paddedU, offsets )
%FFT_FINISH Summary of this function goes here
%   Detailed explanation goes here

numDims = length(size(paddedU));

if numDims == 1
    result = paddedU(offsets(1)+1:end-offsets(1));
elseif numDims == 2
    result = paddedU(offsets(1)+1:end-offsets(1), ...
              offsets(2)+1:end-offsets(2));
elseif numDims == 3
    result = paddedU(offsets(1)+1:end-offsets(1), ...
              offsets(2)+1:end-offsets(2), ...
              offsets(3)+1:end-offsets(3));
end

end

